import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

/// Low-level wrapper around [AudioPlayer] from the just_audio package.
///
/// Exposes only the interface used by the repository so the rest of the
/// code never depends on the just_audio library directly.
abstract class AudioDataSource {
  /// Loads [url], attaching media metadata so the system notification /
  /// lock-screen shows the surah [title] and reciter [artist].
  Future<void> load(
    String url, {
    required String id,
    required String title,
    required String artist,
  });
  Future<void> play();
  Future<void> pause();
  Future<void> seek(Duration position);
  Future<void> stop();

  Stream<Duration> get positionStream;
  Stream<Duration?> get durationStream;
  Stream<bool> get playingStream;
  Stream<PlayerState> get playerStateStream;

  void dispose();
}

class AudioDataSourceImpl implements AudioDataSource {
  final AudioPlayer audioPlayer;

  const AudioDataSourceImpl({required this.audioPlayer});

  @override
  Future<void> load(
    String url, {
    required String id,
    required String title,
    required String artist,
  }) async {
    // A MediaItem tag is required by just_audio_background; it powers the
    // notification + lock-screen metadata and enables background playback.
    await audioPlayer.setAudioSource(
      AudioSource.uri(
        Uri.parse(url),
        tag: MediaItem(
          id: id,
          title: title,
          artist: artist,
          album: "Al-Qur'an",
        ),
      ),
    );
  }

  @override
  Future<void> play() => audioPlayer.play();

  @override
  Future<void> pause() => audioPlayer.pause();

  @override
  Future<void> seek(Duration position) => audioPlayer.seek(position);

  @override
  Future<void> stop() => audioPlayer.stop();

  @override
  Stream<Duration> get positionStream => audioPlayer.positionStream;

  @override
  Stream<Duration?> get durationStream => audioPlayer.durationStream;

  @override
  Stream<bool> get playingStream => audioPlayer.playingStream;

  @override
  Stream<PlayerState> get playerStateStream => audioPlayer.playerStateStream;

  @override
  void dispose() => audioPlayer.dispose();
}
